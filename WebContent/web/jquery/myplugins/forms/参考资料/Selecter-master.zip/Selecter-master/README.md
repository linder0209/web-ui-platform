Selecter
==========

A jQuery plugin for replacing default select elements.

[Documentation and Examples](http://www.benplum.com/formstone/selecter/)